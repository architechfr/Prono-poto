/* ════════════════════════════════════════════════════════════
   PRONO POTO — core screens: Onboarding, Pronos, Match detail
   ════════════════════════════════════════════════════════════ */

function matchState(m){
  if(!m.team1 || !m.team2) return "tbd";
  if(m.score1!=null && m.score2!=null) return "played";
  if(window.H(m.kickoff) <= window.NOW) return "live";
  return "open";
}
function fmtDay(iso){
  const s = new Date(iso).toLocaleDateString("fr-FR",{weekday:"long",day:"numeric",month:"long"});
  return s.charAt(0).toUpperCase()+s.slice(1);
}
function fmtH(iso){ return new Date(iso).toLocaleTimeString("fr-FR",{hour:"2-digit",minute:"2-digit"}); }
function countdown(iso){
  let ms = window.H(iso) - window.NOW; if(ms<=0) return "maintenant";
  const d=Math.floor(ms/864e5), h=Math.floor(ms%864e5/36e5), mn=Math.floor(ms%36e5/6e4);
  if(d>0) return `J-${d} ${h}h`; if(h>0) return `dans ${h}h${String(mn).padStart(2,"0")}`; return `dans ${mn} min`;
}

/* ─── Onboarding (the "Ligue entre amis" entry) ────────────── */
function Onboarding({ onCreate, onJoin }){
  return (
    <div className="pp-onboard">
      <div className="pp-hero">
        <div className="pp-hero-glow" />
        <div className="pp-mascot">⚽</div>
        <div className="pp-brand-big">PRONO <span>POTO</span></div>
        <div className="pp-tagline">Défie tes potos sur le Mondial&nbsp;2026</div>
      </div>

      <div className="pp-valueprops">
        <div className="vp"><span>📝</span><div><b>Pronostique</b> les 104 matchs</div></div>
        <div className="vp"><span>🔒</span><div><b>Verrouillé</b> au coup d'envoi — zéro triche</div></div>
        <div className="vp"><span>⚡</span><div>Score exact <b>×3</b>, bon résultat <b>×1</b>, boost jusqu'à <b>×5</b></div></div>
      </div>

      <div className="pp-onboard-cta">
        <Btn variant="primary" onClick={onCreate}>➕ Créer ma ligue</Btn>
        <Btn variant="alt" onClick={onJoin}>🔑 Rejoindre avec un code</Btn>
      </div>
      <div className="pp-mini-hint">Gratuit · entre potos · aucune appli à installer</div>
    </div>
  );
}

/* ─── Pronos tab ───────────────────────────────────────────── */
function MatchRow({ m, pred, onDelta, onBoost, onOpen }){
  const st = matchState(m);
  const locked = st!=="open";
  const pts = st==="played" && pred ? window.computePoints(pred, m) : null;
  const out = st==="played" && pred ? window.predOutcome(pred, m) : null;

  let badge;
  if(st==="played") badge = <span className="m-real">Réel {m.score1}–{m.score2}</span>;
  else if(st==="live") badge = <span className="m-live"><i/>EN DIRECT</span>;
  else badge = <span className="m-tag">{countdown(m.kickoff)}</span>;

  const stop = (e)=>e.stopPropagation();
  return (
    <div className={"pp-match st-"+st} onClick={onOpen}>
      <div className="m-head">
        <span>{fmtH(m.kickoff)} · {m.venue}</span>
        {badge}
      </div>
      <div className="m-row">
        <div className="m-team"><span className="fl">{window.flag(m.team1)}</span>{m.team1}</div>
        {locked ? (
          <div className="m-score-locked">
            {pred ? <><b>{pred.s1}</b><span>-</span><b>{pred.s2}</b></> : <span className="m-noprono">– pas de prono –</span>}
          </div>
        ) : (
          <div className="m-steppers" onClick={stop}>
            <Stepper value={pred?pred.s1:null} onDelta={d=>onDelta('s1',d)} />
            <Stepper value={pred?pred.s2:null} onDelta={d=>onDelta('s2',d)} />
          </div>
        )}
        <div className="m-team right">{m.team2}<span className="fl">{window.flag(m.team2)}</span></div>
      </div>
      <div className="m-foot">
        <div className="m-foot-left">
          {locked && (pred?.boost>1) && <span className="m-boost-lock">⚡×{pred.boost}</span>}
          {!locked && <span onClick={stop}><Boost boost={pred?.boost||1} onClick={onBoost} /></span>}
          <span className="m-detail-link">{locked?"Voir les pronos des potos ›":"Détails du match ›"}</span>
        </div>
        {pts!=null && (
          <span className={"m-pts "+out}>{out==="exact"?"🎯 ":""}{pts>0?"+":""}{pts} pts</span>
        )}
      </div>
    </div>
  );
}

function Pronos({ matches, pronos, dirty, league, rank, phase, setPhase, onDelta, onBoost, onPublish, onOpen, onGoLeague }){
  const visible = matches.filter(m=> phase==="Tout" ? true : m.stage===phase);
  // group by day
  const groups = [];
  visible.forEach(m=>{
    const day = m.team1 ? fmtDay(m.kickoff) : m.group;
    const g = groups.find(x=>x.day===day);
    if(g) g.items.push(m); else groups.push({day, items:[m]});
  });

  return (
    <div className="pp-screen">
      {/* league strip */}
      <div className="pp-league-strip" onClick={onGoLeague}>
        <div className="ls-trophy">🏆</div>
        <div className="ls-mid">
          <div className="ls-name">{league.name}</div>
          <div className="ls-sub">{league.members} potos · code {league.code}</div>
        </div>
        <div className="ls-rank">
          <div className="ls-rank-pos">{rank.pos===1?"🥇":rank.pos===2?"🥈":rank.pos===3?"🥉":"#"+rank.pos}</div>
          <div className="ls-rank-pts">{rank.points} pts</div>
        </div>
      </div>

      <Sec>📝 Mes pronos</Sec>
      <PhaseChips value={phase} onChange={setPhase} options={window.STAGES} />

      {groups.map(g=>(
        <div key={g.day}>
          <div className="pp-day">{g.day}</div>
          {g.items.map(m=> matchState(m)==="tbd" ? (
            <div key={m.id} className="pp-match tbd">
              <div className="m-head"><span>{fmtH(m.kickoff)} · {m.venue}</span><span className="m-tag">{m.group}</span></div>
              <div className="m-tbd">⏳ Équipes à déterminer — pronos ouverts après le tirage</div>
            </div>
          ) : (
            <MatchRow key={m.id} m={m} pred={pronos[m.id]}
              onDelta={(side,d)=>onDelta(m.id,side,d)} onBoost={()=>onBoost(m.id)} onOpen={()=>onOpen(m.id)} />
          ))}
        </div>
      ))}

      {/* sticky publish */}
      {dirty.length>0 && (
        <div className="pp-publish-dock">
          <Btn variant="primary" onClick={onPublish}>
            📤 Publier mes pronos <span className="pub-count">{dirty.length}</span>
          </Btn>
        </div>
      )}
    </div>
  );
}

/* ─── Match detail (friends' pronos, boosts, lock) ─────────── */
function MatchDetail({ m, pronos, onBack }){
  const st = matchState(m);
  const myPred = pronos[m.id];
  const friends = (window.FRIEND_PREDS[m.id]||[]).slice()
    .sort((a,b)=>{
      const pa=window.computePoints(a,m)??-1, pb=window.computePoints(b,m)??-1;
      return pb-pa;
    });

  return (
    <div className="pp-screen detail">
      <button className="pp-back" onClick={onBack}>‹ Retour</button>

      {/* scoreboard */}
      <div className={"pp-scoreboard st-"+st}>
        <div className="sb-stage">{m.group} · {fmtDay(m.kickoff)} · {fmtH(m.kickoff)}</div>
        <div className="sb-main">
          <div className="sb-team"><div className="sb-fl">{window.flag(m.team1)}</div><div className="sb-nm">{window.teamName(m.team1)}</div></div>
          <div className="sb-score">
            {st==="played" ? <><b>{m.score1}</b><span>:</span><b>{m.score2}</b></>
             : st==="live" ? <><b>{0}</b><span className="sb-live-dot">:</span><b>{0}</b></>
             : <span className="sb-vs">VS</span>}
          </div>
          <div className="sb-team"><div className="sb-fl">{window.flag(m.team2)}</div><div className="sb-nm">{window.teamName(m.team2)}</div></div>
        </div>
        <div className="sb-status">
          {st==="played" && <span className="sb-final">⏱️ Terminé</span>}
          {st==="live" && <span className="sb-livebadge"><i/>EN DIRECT · {m.venue}</span>}
          {st==="open" && <span className="sb-open">🔒 Coup d'envoi {countdown(m.kickoff)}</span>}
        </div>
      </div>

      {/* my prono highlight */}
      {myPred && (
        <Card className="pp-mypred">
          <div className="mp-left"><span className="mp-label">TON PRONO</span>
            <div className="mp-score">{myPred.s1}–{myPred.s2}{myPred.boost>1 && <span className="mp-boost">⚡×{myPred.boost}</span>}</div>
          </div>
          {st==="played"
            ? (()=>{ const out=window.predOutcome(myPred,m), pts=window.computePoints(myPred,m);
                return <div className={"mp-pts "+out}>{out==="exact"?"🎯 Score exact !":out==="good"?"✅ Bon résultat":"❌ Raté"}<b>{pts>0?"+":""}{pts} pts</b></div>; })()
            : <div className="mp-pending">⏳ En attente du résultat</div>}
        </Card>
      )}

      {/* friends */}
      {st==="open" ? (
        <div className="pp-locked-box">
          <div className="lb-lock">🔒</div>
          <div className="lb-title">Pronos verrouillés</div>
          <div className="lb-sub">Les pronos de la ligue se dévoilent au coup d'envoi — {countdown(m.kickoff)}. Pas d'espionnage&nbsp;!</div>
        </div>
      ) : (
        <>
          <Sec right={<span className="pp-sec-count">{friends.length} potos</span>}>👥 Pronos de la ligue</Sec>
          <div className="pp-friendlist">
            {friends.map((f,i)=>{
              const out = st==="played" ? window.predOutcome(f,m) : null;
              const pts = st==="played" ? window.computePoints(f,m) : null;
              return (
                <div key={f.user_id} className={"pp-friend"+(f.me?" me":"")}>
                  <Avatar name={f.pseudo} size={38} ring={f.me?"var(--pp-accent)":undefined} />
                  <div className="fr-mid">
                    <div className="fr-name">{f.pseudo}{f.me && <span className="fr-you">toi</span>}</div>
                    <div className={"fr-dot "+(out||"")}>{out==="exact"?"score exact":out==="good"?"bon résultat":out==="miss"?"raté":"en jeu"}</div>
                  </div>
                  <div className="fr-pred">{f.s1}-{f.s2}{f.boost>1 && <span className="fr-boost">⚡×{f.boost}</span>}</div>
                  <div className={"fr-pts "+(out||"pending")}>{pts!=null?(pts>0?"+":"")+pts:"—"}</div>
                </div>
              );
            })}
          </div>
        </>
      )}

      <div className="pp-legend">Barème : score exact <b>3 pts</b> · bon résultat <b>1 pt</b> · ⚡ multiplie (×2/×3/×5)</div>
    </div>
  );
}

Object.assign(window, { matchState, fmtDay, fmtH, countdown, Onboarding, MatchRow, Pronos, MatchDetail });
