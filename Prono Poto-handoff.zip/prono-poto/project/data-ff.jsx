/* ════════════════════════════════════════════════════════════
   PRONO POTO × FOOT FLASH — extended data for the COMBINED league
   Classement général = Pronos (🎯) + Simulation (🎮) + Quiz (🕹️).
   Loaded AFTER data.jsx (reuses MATCHES / FRIEND_PREDS / flags…).
   ════════════════════════════════════════════════════════════ */

// Categories that feed the general ranking
const CATS = [
  { key:"gen",   label:"Général",    icon:"🏆" },
  { key:"prn",   label:"Pronos",     icon:"🎯" },
  { key:"sim",   label:"Simulation", icon:"🎮" },
  { key:"quiz",  label:"Quiz",       icon:"🕹️" },
];

// Members with a breakdown per category. gen is derived (prn+sim+quiz).
const MEMBERS = [
  { user_id:"u_flo", pseudo:"Flo la Science", me:true,  prn:31, sim:18, quiz:24, exacts:2, streak:3 },
  { user_id:"u_lea", pseudo:"Léa",            me:false, prn:24, sim:14, quiz:30, exacts:2, streak:2 },
  { user_id:"u_max", pseudo:"Maxou",          me:false, prn:27, sim:22, quiz:15, exacts:1, streak:1 },
  { user_id:"u_kar", pseudo:"Karim DTC",      me:false, prn:18, sim:20, quiz:12, exacts:1, streak:0 },
  { user_id:"u_sof", pseudo:"Sofiane",        me:false, prn:14, sim:10, quiz:22, exacts:0, streak:1 },
  { user_id:"u_nad", pseudo:"Nadia 🔥",       me:false, prn:11, sim:16, quiz:18, exacts:1, streak:0 },
  { user_id:"u_tom", pseudo:"Tom Tom",        me:false, prn:7,  sim:8,  quiz:9,  exacts:0, streak:0 },
  { user_id:"u_bib", pseudo:"Bibou",          me:false, prn:3,  sim:4,  quiz:6,  exacts:0, streak:0 },
];
MEMBERS.forEach(m=>{ m.gen = m.prn + m.sim + m.quiz; });

// standings sorted by a given category key
function standingsBy(key){
  return MEMBERS.slice().sort((a,b)=> b[key]-a[key] || b.gen-a.gen);
}

// Simulation snapshot (for the "Simul" detail teaser) — who picked what champion
const SIM_PICKS = [
  { user_id:"u_flo", pseudo:"Flo la Science", me:true,  champ:"FRA", finalist:"ESP", pts:18 },
  { user_id:"u_max", pseudo:"Maxou",          me:false, champ:"BRA", finalist:"FRA", pts:22 },
  { user_id:"u_lea", pseudo:"Léa",            me:false, champ:"ESP", finalist:"ARG", pts:14 },
  { user_id:"u_kar", pseudo:"Karim DTC",      me:false, champ:"FRA", finalist:"ENG", pts:20 },
  { user_id:"u_sof", pseudo:"Sofiane",        me:false, champ:"ARG", finalist:"BRA", pts:10 },
  { user_id:"u_nad", pseudo:"Nadia 🔥",       me:false, champ:"BRA", finalist:"POR", pts:16 },
];

// Quiz snapshot — best run per poto
const QUIZ_SCORES = [
  { user_id:"u_lea", pseudo:"Léa",            me:false, best:30, mode:"Chrono" },
  { user_id:"u_flo", pseudo:"Flo la Science", me:true,  best:24, mode:"Chrono" },
  { user_id:"u_sof", pseudo:"Sofiane",        me:false, best:22, mode:"Libre" },
  { user_id:"u_nad", pseudo:"Nadia 🔥",       me:false, best:18, mode:"Chrono" },
  { user_id:"u_max", pseudo:"Maxou",          me:false, best:15, mode:"Libre" },
  { user_id:"u_kar", pseudo:"Karim DTC",      me:false, best:12, mode:"Chrono" },
];

Object.assign(window, { CATS, MEMBERS, standingsBy, SIM_PICKS, QUIZ_SCORES });
