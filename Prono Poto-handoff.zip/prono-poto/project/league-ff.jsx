/* ════════════════════════════════════════════════════════════
   PRONO POTO × FOOT FLASH — league screens (combined ranking)
   Classement général (Pronos+Simul+Quiz) · Ma ligue · modals
   Uses .pp-* classes (themed gold/navy by the page <style>).
   ════════════════════════════════════════════════════════════ */

function Breakdown({ r }){
  return (
    <div className="ff-break">
      <span>🎯 {r.prn}</span><span>🎮 {r.sim}</span><span>🕹️ {r.quiz}</span>
    </div>
  );
}

function Classement_FF({ cat, setCat, layout, fireConfetti }){
  const standings = window.standingsBy(cat);
  const leader = standings[0]?.[cat] || 1;
  const catMeta = window.CATS.find(c=>c.key===cat);

  const Podium = () => {
    const top3 = standings.slice(0,3);
    const order = [top3[1], top3[0], top3[2]].filter(Boolean);
    const rest = standings.slice(3);
    return (
      <>
        <div className="pp-podium">
          <Confetti fire={fireConfetti} />
          {order.map((r)=>{
            const place = standings.indexOf(r)+1;
            return (
              <div key={r.user_id} className={"pod pod-"+place}>
                <div className="pod-medal">{place===1?"🥇":place===2?"🥈":"🥉"}</div>
                <Avatar name={r.pseudo} size={place===1?60:48} ring={r.me?"var(--pp-accent)":"rgba(255,255,255,.14)"} />
                <div className="pod-name">{r.pseudo}{r.me && <span className="fr-you">toi</span>}</div>
                <div className="pod-pts">{r[cat]}</div>
                <div className="pod-stand"><span>{place}</span></div>
              </div>
            );
          })}
        </div>
        <div className="pp-ranklist">{rest.map((r,i)=><RowList key={r.user_id} r={r} pos={i+4} />)}</div>
      </>
    );
  };

  const RowList = ({ r, pos }) => (
    <div className={"pp-rank list"+(r.me?" me":"")}>
      <span className="rk-pos">{pos}</span>
      <Avatar name={r.pseudo} size={34} ring={r.me?"var(--pp-accent)":undefined} />
      <div className="rk-mid">
        <div className="rk-name">{r.pseudo}{r.me && <span className="fr-you">toi</span>}{r.streak>=3 && <span className="rk-fire"> 🔥{r.streak}</span>}</div>
        {cat==="gen" ? <Breakdown r={r} /> : <div className="rk-sub">{catMeta.icon} {catMeta.label}{cat==="prn"&&r.exacts>0?` · ${r.exacts} exact${r.exacts>1?"s":""}`:""}</div>}
      </div>
      <div className="rk-pts">{r[cat]}<small>pts</small></div>
    </div>
  );

  const Cards = () => (
    <div className="pp-rankcards">
      {standings.map((r,i)=>(
        <div key={r.user_id} className={"pp-rankcard"+(r.me?" me":"")}>
          <div className="rc-pos">{i===0?"🥇":i===1?"🥈":i===2?"🥉":"#"+(i+1)}</div>
          <Avatar name={r.pseudo} size={44} ring={r.me?"var(--pp-accent)":undefined} />
          <div className="rc-mid">
            <div className="rk-name">{r.pseudo}{r.me && <span className="fr-you">toi</span>}</div>
            {cat==="gen" ? <Breakdown r={r} /> : <div className="rk-sub">{catMeta.icon} {catMeta.label}</div>}
            <Bar pct={r[cat]/leader*100} color={i===0?"var(--pp-accent)":"var(--pp-accent2)"} />
          </div>
          <div className="rc-pts">{r[cat]}<small>pts</small></div>
        </div>
      ))}
    </div>
  );

  return (
    <>
      <div className="ff-cats">
        {window.CATS.map(c=>(
          <button key={c.key} className={"ff-cat"+(c.key===cat?" on":"")} onClick={()=>setCat(c.key)}>
            <span>{c.icon}</span>{c.label}
          </button>
        ))}
      </div>
      {cat==="gen" && <div className="ff-formula">🏆 Général = 🎯 Pronos + 🎮 Simulation + 🕹️ Quiz</div>}

      {layout==="podium" ? <Podium/> : layout==="card" ? <Cards/> :
        <div className="pp-ranklist">{standings.map((r,i)=><RowList key={r.user_id} r={r} pos={i+1} />)}</div>}

      {cat==="sim" && <SimTeaser/>}
      {cat==="quiz" && <QuizTeaser/>}
    </>
  );
}

/* simulation picks teaser */
function SimTeaser(){
  return (
    <>
      <Sec>🎮 Pronostics de tournoi</Sec>
      <div className="pp-friendlist">
        {window.SIM_PICKS.map(s=>(
          <div key={s.user_id} className={"pp-friend"+(s.me?" me":"")}>
            <Avatar name={s.pseudo} size={36} ring={s.me?"var(--pp-accent)":undefined} />
            <div className="fr-mid">
              <div className="fr-name">{s.pseudo}{s.me && <span className="fr-you">toi</span>}</div>
              <div className="fr-dot">finaliste {window.flag(s.finalist)} {s.finalist}</div>
            </div>
            <div className="fr-pred">🏆 {window.flag(s.champ)} {s.champ}</div>
            <div className="fr-pts good">{s.pts}</div>
          </div>
        ))}
      </div>
      <div className="pp-legend">Points simul attribués quand les vrais qualifiés / le champion tombent.</div>
    </>
  );
}

/* quiz scores teaser */
function QuizTeaser(){
  return (
    <>
      <Sec>🕹️ Meilleurs scores au Quiz</Sec>
      <div className="pp-friendlist">
        {window.QUIZ_SCORES.map((q,i)=>(
          <div key={q.user_id} className={"pp-friend"+(q.me?" me":"")}>
            <span className="rk-pos">{i===0?"🥇":i===1?"🥈":i===2?"🥉":"#"+(i+1)}</span>
            <Avatar name={q.pseudo} size={36} ring={q.me?"var(--pp-accent)":undefined} />
            <div className="fr-mid">
              <div className="fr-name">{q.pseudo}{q.me && <span className="fr-you">toi</span>}</div>
              <div className="fr-dot">mode {q.mode}</div>
            </div>
            <div className="fr-pts good">{q.best}<small> pts</small></div>
          </div>
        ))}
      </div>
      <div className="pp-legend">Le meilleur score quiz de chaque poto compte dans le général.</div>
    </>
  );
}

/* ─── Ma ligue (invite / code / QR / rules) ────────────────── */
function Ligue_FF({ league, pseudo, onCopy, onShare, onLeave }){
  const link = "footflash.app/?ligue="+league.code;
  return (
    <>
      <Sec>👥 Ma ligue</Sec>
      <div className="pp-invite">
        <div className="iv-name">{league.name}</div>
        <div className="iv-label">Code de la ligue</div>
        <div className="iv-code">{league.code}</div>
        <div className="iv-qr"><QR text={"https://"+link} size={150} /></div>
        <div className="iv-link">{link}</div>
        <div className="iv-actions">
          <Btn variant="primary" onClick={onCopy}>📋 Copier le lien</Btn>
          <Btn variant="alt" onClick={onShare}>📤 Partager</Btn>
        </div>
        <div className="iv-hint">File ce code (ou flashe le QR) à tes potos — ils te rejoignent en 10&nbsp;secondes.</div>
      </div>

      <Sec>Les potos ({window.MEMBERS.length})</Sec>
      <div className="pp-members">
        {window.MEMBERS.map(r=>(
          <div key={r.user_id} className="mb">
            <Avatar name={r.pseudo} size={44} ring={r.me?"var(--pp-accent)":undefined} />
            <span>{r.me?"Toi":r.pseudo.split(" ")[0]}</span>
          </div>
        ))}
        <div className="mb add" onClick={onShare}><div className="mb-add">＋</div><span>Inviter</span></div>
      </div>

      <Card className="pp-rules">
        <div className="rules-h">⚖️ Comment on marque</div>
        <ul>
          <li>🎯 <b>Pronos</b> : score exact <b className="g">3 pts</b> · bon résultat <b className="g">1 pt</b> · × boost ⚡</li>
          <li>🎮 <b>Simulation</b> : points sur tes qualifiés &amp; ton champion une fois connus</li>
          <li>🕹️ <b>Quiz</b> : ton meilleur score (Chrono ou Libre) compte</li>
          <li>🏆 <b>Général</b> = la somme des trois — le vrai classement entre potos</li>
        </ul>
      </Card>

      <div className="pp-leave"><button onClick={onLeave}>🚪 Quitter la ligue sur cet appareil</button></div>
      <div className="pp-acct">Connecté en tant que <b>{pseudo}</b> · <span className="demo-pill">DÉMO</span></div>
    </>
  );
}

/* ─── Create / Join modal bodies ───────────────────────────── */
function CreateModalBody({ onEnter }){
  const [step,setStep] = React.useState(1);
  const [name,setName] = React.useState("");
  const [pseudo,setPseudo] = React.useState("");
  const [code] = React.useState(()=>{ const A="ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; let c=""; for(let i=0;i<6;i++) c+=A[(Math.random()*A.length)|0]; return c; });
  const link = "footflash.app/?ligue="+code;
  if(step===1) return (
    <div className="pp-form">
      <label className="pp-flabel">Nom de ta ligue</label>
      <input className="pp-input" value={name} maxLength={30} placeholder="Ex : Les Cadors du PMU" onChange={e=>setName(e.target.value)} />
      <label className="pp-flabel">Ton pseudo</label>
      <input className="pp-input" value={pseudo} maxLength={20} placeholder="Ex : Flo la Science" onChange={e=>setPseudo(e.target.value)} />
      <Btn variant="primary" disabled={name.trim().length<2||pseudo.trim().length<2} onClick={()=>setStep(2)}>🏆 Créer la ligue</Btn>
    </div>
  );
  return (
    <div className="pp-form success">
      <div className="cs-emoji">🎉</div>
      <div className="cs-title">« {name} » est en ligne !</div>
      <div className="iv-label">Ton code à partager</div>
      <div className="iv-code">{code}</div>
      <div className="iv-qr"><QR text={"https://"+link} size={140} /></div>
      <div className="iv-link">{link}</div>
      <Btn variant="primary" onClick={()=>onEnter({ name:name.trim(), code, pseudo:pseudo.trim() })}>🚀 Entrer dans la ligue</Btn>
    </div>
  );
}
function JoinModalBody({ onEnter }){
  const [pseudo,setPseudo] = React.useState("");
  const [code,setCode] = React.useState("");
  return (
    <div className="pp-form">
      <label className="pp-flabel">Ton pseudo</label>
      <input className="pp-input" value={pseudo} maxLength={20} placeholder="Ex : Flo la Science" onChange={e=>setPseudo(e.target.value)} />
      <label className="pp-flabel">Code de la ligue</label>
      <input className="pp-input code" value={code} maxLength={6} placeholder="CODE" onChange={e=>setCode(e.target.value.toUpperCase())} />
      <Btn variant="primary" disabled={pseudo.trim().length<2||code.trim().length!==6} onClick={()=>onEnter({ name:"Les Cadors du PMU", code:code.trim(), pseudo:pseudo.trim() })}>🚀 C'est parti !</Btn>
      <div className="pp-mini-hint" style={{marginTop:4}}>Pas de code ? Demande-le à l'orga de ta ligue.</div>
    </div>
  );
}

Object.assign(window, { Breakdown, Classement_FF, SimTeaser, QuizTeaser, Ligue_FF, CreateModalBody, JoinModalBody });
