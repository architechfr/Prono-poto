/* ════════════════════════════════════════════════════════════
   PRONO POTO — app shell: state, router, nav, modals, tweaks
   ════════════════════════════════════════════════════════════ */

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#21d07a",
  "standingsLayout": "podium",
  "density": "regular",
  "radius": 16,
  "confetti": true
}/*EDITMODE-END*/;

function NavBtn({ id, icon, label, on, onClick }){
  return (
    <button className={"pp-navbtn"+(on?" on":"")} onClick={onClick}>
      <span className="ico">{icon}</span>{label}
    </button>
  );
}

function App(){
  const [t,setTweak] = useTweaks(TWEAK_DEFAULTS);

  const [league,setLeague] = React.useState(null);
  const [pseudo,setPseudo] = React.useState("Flo la Science");
  const [view,setView] = React.useState("onboard");
  const [detail,setDetail] = React.useState(null);     // match id
  const [modal,setModal] = React.useState(null);        // 'create' | 'join'
  const [phase,setPhase] = React.useState("Tout");
  const [pronos,setPronos] = React.useState(()=>JSON.parse(JSON.stringify(window.MY_PRONOS)));
  const [dirty,setDirty] = React.useState(()=>window.DIRTY.slice());
  const [toast,setToast] = React.useState("");
  const [confettiKey,setConfettiKey] = React.useState(0);
  const toastRef = React.useRef();

  const showToast = (m)=>{ setToast(m); clearTimeout(toastRef.current); toastRef.current=setTimeout(()=>setToast(""),2400); };
  const fireConfetti = ()=>{ if(t.confetti) setConfettiKey(k=>k+1); };

  // rank of "me" in standings
  const meIdx = window.STANDINGS.findIndex(r=>r.me);
  const rank = { pos: meIdx+1, points: window.STANDINGS[meIdx].points };

  const enterLeague = ({ name, code, pseudo:ps })=>{
    setLeague({ ...window.LEAGUE, name, code });
    if(ps) setPseudo(ps);
    setModal(null); setView("pronos"); setDetail(null);
    fireConfetti();
    showToast("🎉 Bienvenue dans « "+name+" » !");
  };

  const go = (v)=>{ setDetail(null); setView(v); document.querySelector(".pp-main")?.scrollTo(0,0); if(v==="classement") fireConfetti(); };

  const onDelta = (id,side,d)=>{
    setPronos(p=>{
      const cur = p[id] ? {...p[id]} : { s1:0, s2:0, boost:1 };
      cur[side] = Math.max(0, Math.min(20, (cur[side]||0)+d));
      return { ...p, [id]:cur };
    });
    setDirty(arr=> arr.includes(id)?arr:[...arr,id]);
  };
  const onBoost = (id)=>{
    const opts=[1,2,3,5];
    setPronos(p=>{
      if(!p[id]){ showToast("Saisis d'abord un score"); return p; }
      const cur={...p[id]}; cur.boost=opts[(opts.indexOf(cur.boost||1)+1)%opts.length];
      showToast(cur.boost>1?("⚡ Boost ×"+cur.boost+" activé !"):"Boost retiré");
      return { ...p, [id]:cur };
    });
    setDirty(arr=> arr.includes(id)?arr:[...arr,id]);
  };
  const onPublish = ()=>{
    if(!dirty.length){ showToast("✅ Tout est déjà publié"); return; }
    showToast("📤 "+dirty.length+" prono"+(dirty.length>1?"s":"")+" publié"+(dirty.length>1?"s":"")+" !");
    setDirty([]); fireConfetti();
  };

  const matches = window.MATCHES;
  const detailMatch = detail!=null ? matches.find(m=>m.id===detail) : null;

  // root css vars from tweaks
  const rootStyle = {
    "--pp-accent": t.accent,
    "--pp-r": t.radius+"px",
  };

  const showNav = league && view!=="onboard" && !detailMatch;

  return (
    <IOSDevice dark width={402} height={874}>
      <div className={"pp-root dens-"+t.density} style={rootStyle}>
        {/* top bar */}
        <div className="pp-topbar">
          <div className="pp-brand">PRONO <span>POTO</span> ⚽</div>
          {league && <span className="demo-pill">DÉMO</span>}
        </div>

        {/* main scroll */}
        <div className="pp-main">
          {detailMatch ? (
            <MatchDetail m={detailMatch} pronos={pronos} onBack={()=>setDetail(null)} />
          ) : !league || view==="onboard" ? (
            <Onboarding onCreate={()=>setModal("create")} onJoin={()=>setModal("join")} />
          ) : view==="classement" ? (
            <Classement standings={window.STANDINGS} league={league} phase={phase} setPhase={setPhase}
              layout={t.standingsLayout} dirty={dirty} onPublish={onPublish} fireConfetti={confettiKey} />
          ) : view==="ligue" ? (
            <Ligue league={league} pseudo={pseudo} standings={window.STANDINGS}
              onCopy={()=>showToast("📋 Lien d'invitation copié !")}
              onShare={()=>showToast("📤 Partagé à tes potos !")}
              onLeave={()=>{ if(confirm("Quitter la ligue sur cet appareil ?")){ setLeague(null); setView("onboard"); } }} />
          ) : (
            <Pronos matches={matches} pronos={pronos} dirty={dirty} league={league} rank={rank}
              phase={phase} setPhase={setPhase} onDelta={onDelta} onBoost={onBoost}
              onPublish={onPublish} onOpen={(id)=>setDetail(id)} onGoLeague={()=>go("ligue")} />
          )}
        </div>

        {/* bottom nav */}
        {showNav && (
          <div className="pp-nav">
            <NavBtn id="pronos" icon="📝" label="Pronos" on={view==="pronos"} onClick={()=>go("pronos")} />
            <NavBtn id="classement" icon="🏆" label="Classement" on={view==="classement"} onClick={()=>go("classement")} />
            <NavBtn id="ligue" icon="👥" label="Ma ligue" on={view==="ligue"} onClick={()=>go("ligue")} />
          </div>
        )}

        <Toast msg={toast} />

        {/* modals */}
        <Modal open={modal==="create"} onClose={()=>setModal(null)} title="➕ Créer une ligue">
          <CreateModalBody onEnter={enterLeague} />
        </Modal>
        <Modal open={modal==="join"} onClose={()=>setModal(null)} title="🔑 Rejoindre une ligue">
          <JoinModalBody onEnter={enterLeague} />
        </Modal>
      </div>

      {/* Tweaks */}
      <TweaksPanel>
        <TweakSection label="Classement" />
        <TweakRadio label="Affichage" value={t.standingsLayout} options={["podium","card","list"]}
          onChange={v=>setTweak("standingsLayout",v)} />
        <TweakSection label="Style" />
        <TweakColor label="Accent" value={t.accent}
          options={["#21d07a","#ff7a59","#7c5cff","#00c2ff","#ffd84d"]} onChange={v=>setTweak("accent",v)} />
        <TweakSlider label="Arrondi" value={t.radius} min={6} max={26} step={2} unit="px"
          onChange={v=>setTweak("radius",v)} />
        <TweakRadio label="Densité" value={t.density} options={["compact","regular","comfy"]}
          onChange={v=>setTweak("density",v)} />
        <TweakToggle label="Confettis 🎉" value={t.confetti} onChange={v=>setTweak("confetti",v)} />
      </TweaksPanel>
    </IOSDevice>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
