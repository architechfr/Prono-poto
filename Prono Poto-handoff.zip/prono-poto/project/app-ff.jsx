/* ════════════════════════════════════════════════════════════
   PRONO POTO × FOOT FLASH — app shell (gold/navy, native skin)
   Demonstrates the league living INSIDE Foot Flash's nav.
   ════════════════════════════════════════════════════════════ */

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#e8c45c",
  "standingsLayout": "podium",
  "density": "regular",
  "radius": 14,
  "confetti": true
}/*EDITMODE-END*/;

// Foot Flash bottom nav (10 tabs, 2 rows). wired = interactive in this proto.
const FF_TABS = [
  { k:"cal",    ic:"📅", l:"Matchs" },
  { k:"groups", ic:"🏆", l:"Groupes" },
  { k:"teams",  ic:"👥", l:"Équipes" },
  { k:"bracket",ic:"🏅", l:"Tableau" },
  { k:"simul",  ic:"🎮", l:"Simul", wired:true },
  { k:"prono",  ic:"🎯", l:"Pronos", wired:true },
  { k:"game",   ic:"🕹️", l:"Jeu", wired:true },
  { k:"ligue",  ic:"🤝", l:"Ligue", wired:true, isNew:true },
  { k:"news",   ic:"📰", l:"Actus" },
  { k:"settings",ic:"⚙️",l:"Réglages" },
];

function App(){
  const [t,setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [view,setView] = React.useState("ligue");
  const [sub,setSub] = React.useState("classement");   // ligue subview
  const [cat,setCat] = React.useState("gen");
  const [detail,setDetail] = React.useState(null);
  const [modal,setModal] = React.useState(null);
  const [league,setLeague] = React.useState(null);
  const [pseudo,setPseudo] = React.useState("Flo la Science");
  const [pronos,setPronos] = React.useState(()=>JSON.parse(JSON.stringify(window.MY_PRONOS)));
  const [dirty,setDirty] = React.useState(()=>window.DIRTY.slice());
  const [toast,setToast] = React.useState("");
  const [confettiKey,setConfettiKey] = React.useState(0);
  const toastRef = React.useRef();

  const showToast = (m)=>{ setToast(m); clearTimeout(toastRef.current); toastRef.current=setTimeout(()=>setToast(""),2400); };
  const fireConfetti = ()=>{ if(t.confetti) setConfettiKey(k=>k+1); };

  const me = window.MEMBERS.find(m=>m.me);
  const genRank = window.standingsBy("gen").findIndex(m=>m.me)+1;

  const enterLeague = ({ name, code, pseudo:ps })=>{
    setLeague({ id:"demo", code, name, members:window.MEMBERS.length });
    if(ps) setPseudo(ps);
    setModal(null); setView("ligue"); setSub("classement"); setDetail(null);
    fireConfetti(); showToast("🎉 Bienvenue dans « "+name+" » !");
  };
  const go = (v)=>{ setDetail(null); setView(v); document.querySelector(".pp-main")?.scrollTo(0,0); if(v==="ligue"&&sub==="classement") fireConfetti(); };

  const onDelta = (id,side,d)=>{
    setPronos(p=>{ const cur=p[id]?{...p[id]}:{s1:0,s2:0,boost:1}; cur[side]=Math.max(0,Math.min(20,(cur[side]||0)+d)); return {...p,[id]:cur}; });
    setDirty(a=>a.includes(id)?a:[...a,id]);
  };
  const onBoost = (id)=>{
    const opts=[1,2,3,5];
    setPronos(p=>{ if(!p[id]){showToast("Saisis d'abord un score");return p;} const cur={...p[id]}; cur.boost=opts[(opts.indexOf(cur.boost||1)+1)%opts.length]; showToast(cur.boost>1?("⚡ Boost ×"+cur.boost+" activé !"):"Boost retiré"); return {...p,[id]:cur}; });
    setDirty(a=>a.includes(id)?a:[...a,id]);
  };
  const onPublish = ()=>{
    if(!dirty.length){ showToast("✅ Tout est déjà publié"); return; }
    showToast("📤 "+dirty.length+" prono"+(dirty.length>1?"s":"")+" publié"+(dirty.length>1?"s":"")+" !");
    setDirty([]); fireConfetti();
  };

  const detailMatch = detail!=null ? window.MATCHES.find(m=>m.id===detail) : null;
  const rootStyle = { "--pp-accent": t.accent, "--pp-r": t.radius+"px" };

  /* ── Pronos hub (mock of rProno with the league entry card) ── */
  const PronosHub = () => {
    const open = window.MATCHES.filter(m=>m.team1 && window.matchState(m)!=="tbd");
    return (
      <>
        {league ? (
          <div className="ff-league-cta in" onClick={()=>go("ligue")}>
            <div className="lc-ic">🏆</div>
            <div className="lc-mid"><div className="lc-t">{league.name}</div><div className="lc-s">Tu es <b>#{genRank}</b> au général · {league.members} potos</div></div>
            <div className="lc-go">›</div>
          </div>
        ) : (
          <div className="ff-league-cta">
            <div className="lc-head"><span className="lc-ic">🏆</span><div><div className="lc-t">Ligue entre amis</div><div className="lc-s">Défie tes potos : pronos, simulation &amp; quiz dans un seul classement.</div></div></div>
            <div className="lc-btns">
              <Btn variant="primary" onClick={()=>setModal("create")}>➕ Créer</Btn>
              <Btn variant="alt" onClick={()=>setModal("join")}>🔑 Rejoindre</Btn>
            </div>
          </div>
        )}
        <Sec>🎯 Mes pronos</Sec>
        {open.slice(0,5).map(m=>(
          <MatchRow key={m.id} m={m} pred={pronos[m.id]} onDelta={(s,d)=>onDelta(m.id,s,d)} onBoost={()=>onBoost(m.id)} onOpen={()=>setDetail(m.id)} />
        ))}
        {dirty.length>0 && (
          <div className="pp-publish-dock"><Btn variant="primary" onClick={onPublish}>📤 Publier mes pronos <span className="pub-count">{dirty.length}</span></Btn></div>
        )}
      </>
    );
  };

  /* ── Ligue tab ── */
  const LigueTab = () => {
    if(!league) return (
      <div className="ff-entry">
        <div className="ff-entry-trophy">🏆</div>
        <div className="ff-entry-title">Ligue entre amis</div>
        <div className="ff-entry-sub">Un seul classement pour tes <b>pronos</b>, ta <b>simulation</b> et le <b>quiz</b>. Crée ta ligue ou rejoins celle de tes potos.</div>
        <div className="ff-entry-props">
          <div className="ep"><span>🎯</span><div>Pronos verrouillés au coup d'envoi</div></div>
          <div className="ep"><span>🎮</span><div>Ta simulation de tournoi comptabilisée</div></div>
          <div className="ep"><span>🕹️</span><div>Tes scores de quiz dans la course</div></div>
        </div>
        <div className="ff-entry-cta">
          <Btn variant="primary" onClick={()=>setModal("create")}>➕ Créer ma ligue</Btn>
          <Btn variant="alt" onClick={()=>setModal("join")}>🔑 Rejoindre avec un code</Btn>
        </div>
      </div>
    );
    return (
      <>
        <div className="ff-league-strip">
          <div className="ls-trophy">🏆</div>
          <div className="ls-mid"><div className="ls-name">{league.name}</div><div className="ls-sub">{league.members} potos · code {league.code}</div></div>
          <div className="ls-rank"><div className="ls-rank-pos">{genRank===1?"🥇":genRank===2?"🥈":genRank===3?"🥉":"#"+genRank}</div><div className="ls-rank-pts">{me.gen} pts</div></div>
        </div>
        <div className="ff-subnav">
          <button className={sub==="classement"?"on":""} onClick={()=>{setSub("classement");fireConfetti();}}>🏆 Classement</button>
          <button className={sub==="info"?"on":""} onClick={()=>setSub("info")}>👥 Ma ligue</button>
        </div>
        {sub==="classement" ? (
          <>
            <Classement_FF cat={cat} setCat={setCat} layout={t.standingsLayout} fireConfetti={confettiKey} />
            {dirty.length>0 && <div className="pp-publish-dock"><Btn variant="primary" onClick={onPublish}>📤 Publier mes pronos <span className="pub-count">{dirty.length}</span></Btn></div>}
          </>
        ) : (
          <Ligue_FF league={league} pseudo={pseudo}
            onCopy={()=>showToast("📋 Lien d'invitation copié !")}
            onShare={()=>showToast("📤 Partagé à tes potos !")}
            onLeave={()=>{ if(confirm("Quitter la ligue sur cet appareil ?")){ setLeague(null);} }} />
        )}
      </>
    );
  };

  const SimulTab = () => (
    <>
      <Sec>🎮 Simulation</Sec>
      <div className="ff-note">🏆 Ton pronostic de tournoi (qualifiés + champion) <b>alimente le classement général</b> de ta ligue. {league?`Tu marques actuellement ${me.sim} pts simul.`:"Rejoins une ligue pour te comparer aux potos."}</div>
      {window.SIM_PICKS && <SimTeaser/>}
    </>
  );
  const JeuTab = () => (
    <>
      <Sec>🕹️ Jeu — Quiz Coupe du Monde</Sec>
      <div className="ff-note">🏆 Ton <b>meilleur score quiz</b> compte dans le classement général. {league?`Toi : ${me.quiz} pts quiz.`:"Rejoins une ligue pour défier tes potos au quiz."}</div>
      {window.QUIZ_SCORES && <QuizTeaser/>}
    </>
  );
  const Placeholder = ({label}) => (
    <div className="ff-placeholder"><div className="fp-ic">🔧</div><div className="fp-t">Écran Foot Flash existant</div><div className="fp-s">« {label} » — inchangé. Prono Poto s'ajoute sans rien casser.</div></div>
  );

  const showNav = !detailMatch;
  const activeTab = FF_TABS.find(x=>x.k===view);

  return (
    <IOSDevice dark width={402} height={874}>
      <div className={"pp-root ff dens-"+t.density} style={rootStyle}>
        <div className="ff-hdr">
          <div className="ff-title">FOOT <span>FLASH</span> 2026</div>
          <div className="ff-myteam">🇫🇷 Mon équipe&nbsp;: France</div>
        </div>

        <div className="pp-main">
          {detailMatch ? <MatchDetail m={detailMatch} pronos={pronos} onBack={()=>setDetail(null)} />
            : view==="ligue" ? <LigueTab/>
            : view==="prono" ? <PronosHub/>
            : view==="simul" ? <SimulTab/>
            : view==="game" ? <JeuTab/>
            : <Placeholder label={activeTab?activeTab.l:view} />}
        </div>

        {showNav && (
          <div className="ff-nav">
            {FF_TABS.map(tab=>(
              <button key={tab.k} className={(view===tab.k?"on ":"")+(tab.wired?"":"dim")} onClick={()=>go(tab.k)}>
                <span className="ic">{tab.ic}{tab.isNew && <i className="new-dot"/>}</span>{tab.l}
              </button>
            ))}
          </div>
        )}

        <Toast msg={toast} />
        <Modal open={modal==="create"} onClose={()=>setModal(null)} title="➕ Créer une ligue"><CreateModalBody onEnter={enterLeague} /></Modal>
        <Modal open={modal==="join"} onClose={()=>setModal(null)} title="🔑 Rejoindre une ligue"><JoinModalBody onEnter={enterLeague} /></Modal>
      </div>

      <TweaksPanel>
        <TweakSection label="Classement" />
        <TweakRadio label="Affichage" value={t.standingsLayout} options={["podium","card","list"]} onChange={v=>setTweak("standingsLayout",v)} />
        <TweakSection label="Style" />
        <TweakColor label="Accent" value={t.accent} options={["#e8c45c","#FFB300","#21d07a","#46a0ff","#ff5d73"]} onChange={v=>setTweak("accent",v)} />
        <TweakSlider label="Arrondi" value={t.radius} min={6} max={22} step={2} unit="px" onChange={v=>setTweak("radius",v)} />
        <TweakRadio label="Densité" value={t.density} options={["compact","regular","comfy"]} onChange={v=>setTweak("density",v)} />
        <TweakToggle label="Confettis 🎉" value={t.confetti} onChange={v=>setTweak("confetti",v)} />
      </TweaksPanel>
    </IOSDevice>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
