/* ════════════════════════════════════════════════════════════
   PRONO POTO — league screens: Classement (3 layouts),
   Ma ligue, Create & Join modal bodies
   ════════════════════════════════════════════════════════════ */

/* ─── Classement ───────────────────────────────────────────── */
function Classement({ standings, league, phase, setPhase, layout, dirty, onPublish, fireConfetti }){
  const leader = standings[0]?.points || 1;

  const Podium = () => {
    const top3 = standings.slice(0,3);
    const order = [top3[1], top3[0], top3[2]].filter(Boolean); // 2 · 1 · 3
    const rest = standings.slice(3);
    return (
      <>
        <div className="pp-podium">
          <Confetti fire={fireConfetti} />
          {order.map((r)=>{
            const place = standings.indexOf(r)+1;
            return (
              <div key={r.user_id} className={"pod pod-"+place}>
                <div className="pod-medal">{place===1?"🥇":place===2?"🥈":"🥉"}</div>
                <Avatar name={r.pseudo} size={place===1?64:52} ring={r.me?"var(--pp-accent)":"rgba(255,255,255,.15)"} />
                <div className="pod-name">{r.pseudo}{r.me && <span className="fr-you">toi</span>}</div>
                <div className="pod-pts">{r.points}</div>
                <div className="pod-stand"><span>{place}</span></div>
              </div>
            );
          })}
        </div>
        <div className="pp-ranklist">
          {rest.map((r,i)=> <RankList key={r.user_id} r={r} pos={i+4} leader={leader} />)}
        </div>
      </>
    );
  };

  const RankList = ({ r, pos, leader }) => (
    <div className={"pp-rank list"+(r.me?" me":"")}>
      <span className="rk-pos">{pos}</span>
      <Avatar name={r.pseudo} size={34} ring={r.me?"var(--pp-accent)":undefined} />
      <div className="rk-mid">
        <div className="rk-name">{r.pseudo}{r.me && <span className="fr-you">toi</span>}</div>
        <div className="rk-sub">{r.exacts} exact{r.exacts>1?"s":""} · {r.played} match{r.played>1?"s":""}{r.streak>=3 && <span className="rk-fire"> · 🔥 {r.streak}</span>}</div>
      </div>
      <div className="rk-pts">{r.points}<small>pts</small></div>
    </div>
  );

  const Cards = () => (
    <div className="pp-rankcards">
      {standings.map((r,i)=>(
        <div key={r.user_id} className={"pp-rankcard"+(r.me?" me":"")}>
          <div className="rc-pos">{i===0?"🥇":i===1?"🥈":i===2?"🥉":"#"+(i+1)}</div>
          <Avatar name={r.pseudo} size={46} ring={r.me?"var(--pp-accent)":undefined} />
          <div className="rc-mid">
            <div className="rk-name">{r.pseudo}{r.me && <span className="fr-you">toi</span>}</div>
            <div className="rk-sub">{r.exacts} score{r.exacts>1?"s":""} exact{r.exacts>1?"s":""} · {r.played} match{r.played>1?"s":""}{r.streak>=3 && <span className="rk-fire"> · 🔥 série {r.streak}</span>}</div>
            <Bar pct={r.points/leader*100} color={i===0?"var(--pp-yellow)":"var(--pp-accent)"} />
          </div>
          <div className="rc-pts">{r.points}<small>pts</small></div>
        </div>
      ))}
    </div>
  );

  return (
    <div className="pp-screen">
      <Sec right={<span className="pp-sec-count">{league.members} potos</span>}>🏆 {league.name}</Sec>
      <PhaseChips value={phase} onChange={setPhase} options={window.STAGES} />
      {layout==="podium" ? <Podium/> : layout==="card" ? <Cards/> :
        <div className="pp-ranklist">{standings.map((r,i)=> <RankList key={r.user_id} r={r} pos={i+1} leader={leader} />)}</div>}

      {dirty.length>0 && (
        <div className="pp-publish-dock">
          <Btn variant="primary" onClick={onPublish}>📤 Publier mes pronos <span className="pub-count">{dirty.length}</span></Btn>
        </div>
      )}
    </div>
  );
}

/* ─── Ma ligue (invite / code / QR / rules) ────────────────── */
function Ligue({ league, pseudo, standings, onCopy, onShare, onLeave }){
  const link = "pronopoto.app/?ligue="+league.code;
  return (
    <div className="pp-screen">
      <Sec>👥 Ma ligue</Sec>

      <div className="pp-invite">
        <div className="iv-name">{league.name}</div>
        <div className="iv-label">Code de la ligue</div>
        <div className="iv-code">{league.code}</div>
        <div className="iv-qr"><QR text={"https://"+link} size={150} /></div>
        <div className="iv-link">{link}</div>
        <div className="iv-actions">
          <Btn variant="primary" onClick={onCopy}>📋 Copier le lien</Btn>
          <Btn variant="alt" onClick={onShare}>📤 Partager</Btn>
        </div>
        <div className="iv-hint">File ce code (ou flashe le QR) à tes potos — ils te rejoignent en 10&nbsp;secondes.</div>
      </div>

      <Sec>Les potos ({league.members})</Sec>
      <div className="pp-members">
        {standings.map(r=> (
          <div key={r.user_id} className="mb">
            <Avatar name={r.pseudo} size={46} ring={r.me?"var(--pp-accent)":undefined} />
            <span>{r.me?"Toi":r.pseudo.split(" ")[0]}</span>
          </div>
        ))}
        <div className="mb add" onClick={onShare}><div className="mb-add">＋</div><span>Inviter</span></div>
      </div>

      <Card className="pp-rules">
        <div className="rules-h">⚖️ Règles du jeu</div>
        <ul>
          <li>Score exact : <b className="g">3 pts</b> · bon résultat (1/N/2) : <b className="g">1 pt</b></li>
          <li>Boost ⚡ ×2 / ×3 / ×5 — multiplie tes points sur le match</li>
          <li>Pronos modifiables jusqu'au coup d'envoi, puis 🔒 verrouillés par le serveur</li>
          <li>Les pronos des potos n'apparaissent qu'après le coup d'envoi</li>
        </ul>
      </Card>

      <div className="pp-leave"><button onClick={onLeave}>🚪 Quitter la ligue sur cet appareil</button></div>
      <div className="pp-acct">Connecté en tant que <b>{pseudo}</b> · <span className="demo-pill">MODE DÉMO</span></div>
    </div>
  );
}

/* ─── Create modal ─────────────────────────────────────────── */
function CreateModalBody({ onEnter }){
  const [step,setStep] = React.useState(1);
  const [name,setName] = React.useState("");
  const [pseudo,setPseudo] = React.useState("");
  const [code] = React.useState(()=>{
    const A="ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; let c=""; for(let i=0;i<6;i++) c+=A[(Math.random()*A.length)|0]; return c;
  });
  const link = "pronopoto.app/?ligue="+code;

  if(step===1) return (
    <div className="pp-form">
      <label className="pp-flabel">Nom de ta ligue</label>
      <input className="pp-input" value={name} maxLength={30} placeholder="Ex : Les Cadors du PMU" onChange={e=>setName(e.target.value)} />
      <label className="pp-flabel">Ton pseudo</label>
      <input className="pp-input" value={pseudo} maxLength={20} placeholder="Ex : Flo la Science" onChange={e=>setPseudo(e.target.value)} />
      <Btn variant="primary" disabled={name.trim().length<2||pseudo.trim().length<2} onClick={()=>setStep(2)}>🏆 Créer la ligue</Btn>
    </div>
  );
  return (
    <div className="pp-form success">
      <div className="cs-emoji">🎉</div>
      <div className="cs-title">« {name} » est en ligne !</div>
      <div className="iv-label">Ton code à partager</div>
      <div className="iv-code">{code}</div>
      <div className="iv-qr"><QR text={"https://"+link} size={140} /></div>
      <div className="iv-link">{link}</div>
      <Btn variant="primary" onClick={()=>onEnter({ name:name.trim(), code, pseudo:pseudo.trim() })}>🚀 Entrer dans la ligue</Btn>
    </div>
  );
}

/* ─── Join modal ───────────────────────────────────────────── */
function JoinModalBody({ presetCode="", onEnter }){
  const [pseudo,setPseudo] = React.useState("");
  const [code,setCode] = React.useState(presetCode);
  return (
    <div className="pp-form">
      <label className="pp-flabel">Ton pseudo</label>
      <input className="pp-input" value={pseudo} maxLength={20} placeholder="Ex : Flo la Science" onChange={e=>setPseudo(e.target.value)} />
      <label className="pp-flabel">Code de la ligue</label>
      <input className="pp-input code" value={code} maxLength={6} placeholder="CODE" onChange={e=>setCode(e.target.value.toUpperCase())} />
      <Btn variant="primary" disabled={pseudo.trim().length<2||code.trim().length!==6}
           onClick={()=>onEnter({ name:"Les Cadors du PMU", code:code.trim(), pseudo:pseudo.trim() })}>🚀 C'est parti !</Btn>
      <div className="pp-mini-hint" style={{marginTop:4}}>Tu n'as pas de code ? Demande-le à l'organisateur de ta ligue.</div>
    </div>
  );
}

Object.assign(window, { Classement, Ligue, CreateModalBody, JoinModalBody });
