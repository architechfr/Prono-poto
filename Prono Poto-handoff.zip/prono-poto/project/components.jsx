/* ════════════════════════════════════════════════════════════
   PRONO POTO — shared UI primitives
   Styling lives mostly in the page <style>; tweakable values come
   through CSS vars (--pp-accent, --pp-accent-d, --pp-r, --pp-gap).
   ════════════════════════════════════════════════════════════ */

/* ─── Avatar — colourful initial bubble, colour hashed from pseudo ── */
const AV_COLORS = ["#21d07a","#ffd84d","#ff7a59","#7c5cff","#00c2ff","#ff4d6a","#36d6c3","#ff9f1c"];
function avColor(name){
  let h=0; for(let i=0;i<name.length;i++) h=(h*31 + name.charCodeAt(i))>>>0;
  return AV_COLORS[h % AV_COLORS.length];
}
function Avatar({ name, size=40, ring }){
  const c = avColor(name);
  const initials = name.replace(/[^\p{L}\p{N} ]/gu,"").trim().split(/\s+/).slice(0,2).map(w=>w[0]||"").join("").toUpperCase()||"?";
  return (
    <div style={{
      width:size, height:size, borderRadius:"50%", flexShrink:0,
      display:"flex", alignItems:"center", justifyContent:"center",
      fontFamily:"var(--pp-display)", fontWeight:800, fontSize:size*0.42, color:"#1a1206",
      background:`radial-gradient(circle at 32% 28%, ${c}, ${c} 60%, rgba(0,0,0,0.25))`,
      boxShadow: ring?`0 0 0 3px ${ring}, 0 4px 10px rgba(0,0,0,.3)`:"0 3px 8px rgba(0,0,0,.3)",
      letterSpacing:0,
    }}>{initials}</div>
  );
}

/* ─── Button ───────────────────────────────────────────────── */
function Btn({ children, onClick, variant="primary", style={}, disabled }){
  return (
    <button className={"pp-btn pp-btn-"+variant} onClick={onClick} disabled={disabled} style={style}>
      {children}
    </button>
  );
}

/* ─── Card ─────────────────────────────────────────────────── */
function Card({ children, style={}, className="", onClick, accent }){
  return (
    <div className={"pp-card "+className} onClick={onClick}
         style={{ ...(accent?{borderColor:accent, background:`color-mix(in srgb, ${accent} 8%, var(--pp-card))`}:{}), ...style }}>
      {children}
    </div>
  );
}

/* ─── Section header ───────────────────────────────────────── */
function Sec({ children, right }){
  return (
    <div className="pp-sec">
      <span>{children}</span>
      {right}
    </div>
  );
}

/* ─── Phase filter — segmented chips ───────────────────────── */
function PhaseChips({ value, onChange, options }){
  return (
    <div className="pp-chips">
      {options.map(o=>(
        <button key={o} className={"pp-chip"+(o===value?" on":"")} onClick={()=>onChange(o)}>{o}</button>
      ))}
    </div>
  );
}

/* ─── Progress bar ─────────────────────────────────────────── */
function Bar({ pct, color }){
  return (
    <div className="pp-bar"><div className="pp-bar-fill" style={{ width:Math.max(4,pct)+"%", background:color||"var(--pp-accent)" }} /></div>
  );
}

/* ─── Score stepper ────────────────────────────────────────── */
function Stepper({ value, onDelta, locked }){
  return (
    <div className={"pp-step"+(locked?" locked":"")}>
      {!locked && <button onClick={()=>onDelta(-1)} aria-label="moins">−</button>}
      <span className="val">{value==null?"–":value}</span>
      {!locked && <button onClick={()=>onDelta(1)} aria-label="plus">+</button>}
    </div>
  );
}

/* ─── Boost chip (cycles 1→2→3→5) ──────────────────────────── */
function Boost({ boost=1, locked, onClick }){
  const on = boost>1;
  return (
    <button className={"pp-boost"+(on?" on":"")+(locked?" locked":"")}
            onClick={locked?undefined:onClick} aria-label="boost">
      ⚡{on?<b>×{boost}</b>:null}
    </button>
  );
}

/* ─── Modal (bottom-sheet on mobile) ───────────────────────── */
function Modal({ open, onClose, children, title }){
  if(!open) return null;
  return (
    <div className="pp-modal-scrim" onClick={onClose}>
      <div className="pp-sheet" onClick={e=>e.stopPropagation()}>
        <div className="pp-sheet-grip" />
        {title && <div className="pp-sheet-title">{title}</div>}
        {children}
      </div>
    </div>
  );
}

/* ─── QR code (real, via qrcode-generator CDN) ─────────────── */
function QR({ text, size=160 }){
  const html = React.useMemo(()=>{
    try{
      const qr = window.qrcode(0, "M");
      qr.addData(text); qr.make();
      // build crisp SVG ourselves so we can theme it
      const n = qr.getModuleCount();
      const cell = size/n;
      let rects="";
      for(let r=0;r<n;r++) for(let c=0;c<n;c++){
        if(qr.isDark(r,c)) rects+=`<rect x="${(c*cell).toFixed(2)}" y="${(r*cell).toFixed(2)}" width="${cell.toFixed(2)}" height="${cell.toFixed(2)}" rx="${(cell*0.32).toFixed(2)}"/>`;
      }
      return `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" fill="#0d1421">${rects}</svg>`;
    }catch(e){ return `<div style="width:${size}px;height:${size}px"></div>`; }
  }, [text, size]);
  return <div className="pp-qr" dangerouslySetInnerHTML={{ __html: html }} />;
}

/* ─── Confetti burst (lightweight canvas) ──────────────────── */
function Confetti({ fire }){
  const ref = React.useRef(null);
  React.useEffect(()=>{
    if(!fire) return;
    const cv = ref.current; if(!cv) return;
    const ctx = cv.getContext("2d");
    const W = cv.width = cv.offsetWidth, Hh = cv.height = cv.offsetHeight;
    const COLORS=["#21d07a","#ffd84d","#ff7a59","#7c5cff","#00c2ff","#ff4d6a"];
    const parts = Array.from({length:90},()=>({
      x: W/2 + (Math.random()-0.5)*60, y: Hh*0.32,
      vx:(Math.random()-0.5)*9, vy:-(Math.random()*11+5),
      g:0.32+Math.random()*0.12, s:5+Math.random()*6,
      rot:Math.random()*6.28, vr:(Math.random()-0.5)*0.4,
      c:COLORS[(Math.random()*COLORS.length)|0], life:0
    }));
    let raf, t=0;
    const tick=()=>{
      ctx.clearRect(0,0,W,Hh); t++;
      parts.forEach(p=>{
        p.vy+=p.g; p.x+=p.vx; p.y+=p.vy; p.rot+=p.vr; p.life++;
        ctx.save(); ctx.translate(p.x,p.y); ctx.rotate(p.rot);
        ctx.globalAlpha=Math.max(0,1-p.life/110); ctx.fillStyle=p.c;
        ctx.fillRect(-p.s/2,-p.s/2,p.s,p.s*0.6); ctx.restore();
      });
      if(t<120) raf=requestAnimationFrame(tick); else ctx.clearRect(0,0,W,Hh);
    };
    tick();
    return ()=>cancelAnimationFrame(raf);
  }, [fire]);
  return <canvas ref={ref} className="pp-confetti" />;
}

/* ─── Toast ────────────────────────────────────────────────── */
function Toast({ msg }){
  return <div className={"pp-toast"+(msg?" show":"")}>{msg}</div>;
}

Object.assign(window, {
  avColor, Avatar, Btn, Card, Sec, PhaseChips, Bar, Stepper, Boost, Modal, QR, Confetti, Toast,
});
