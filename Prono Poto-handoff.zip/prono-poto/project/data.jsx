/* ════════════════════════════════════════════════════════════
   PRONO POTO — demo data for the design prototype
   Deterministic "NOW" so the proto reliably shows every state
   (played / locked-live / open / TBD). Mirrors the real app's
   shape: matches{ id,kickoff,stage,team1,team2,score1,score2 },
   standings, and per-match friend predictions with boosts.
   ════════════════════════════════════════════════════════════ */

// Simulated current moment — mid-tournament so we see results + live + upcoming
const NOW = new Date("2026-06-22T20:35:00+02:00").getTime();

const FLAGS = {
  FRA:"🇫🇷",SEN:"🇸🇳",IRQ:"🇮🇶",NOR:"🇳🇴",MEX:"🇲🇽",KOR:"🇰🇷",RSA:"🇿🇦",CZE:"🇨🇿",
  BRA:"🇧🇷",ARG:"🇦🇷",ESP:"🇪🇸",GER:"🇩🇪",ENG:"🏴󠁧󠁢󠁥󠁮󠁧󠁿",POR:"🇵🇹",NED:"🇳🇱",BEL:"🇧🇪",CRO:"🇭🇷",MAR:"🇲🇦",
  USA:"🇺🇸",CAN:"🇨🇦",JPN:"🇯🇵",SUI:"🇨🇭",URU:"🇺🇾",COL:"🇨🇴",AUT:"🇦🇹",TUR:"🇹🇷",AUS:"🇦🇺",
  GHA:"🇬🇭",EGY:"🇪🇬",SWE:"🇸🇪",QAT:"🇶🇦"
};
function flag(c){ return FLAGS[c] || "🏳️"; }

// Full team names for the match-detail header
const TEAM_NAMES = {
  FRA:"France",SEN:"Sénégal",IRQ:"Irak",NOR:"Norvège",MEX:"Mexique",KOR:"Corée du Sud",
  RSA:"Afrique du Sud",CZE:"Tchéquie",BRA:"Brésil",ARG:"Argentine",ESP:"Espagne",
  GER:"Allemagne",ENG:"Angleterre",NED:"Pays-Bas",POR:"Portugal",MAR:"Maroc",CRO:"Croatie"
};
function teamName(c){ return TEAM_NAMES[c] || c; }

// kickoff helpers
const H = (iso) => new Date(iso).getTime();

/* ─── Matches ──────────────────────────────────────────────── */
// played: score1/score2 set · live: kickoff passed, score null · open: future · tbd: no teams
const MATCHES = [
  // — Groupe I (la poule de "Les Cadors") —
  { id:49, kickoff:"2026-06-16T19:00:00+02:00", stage:"Groupes", group:"Groupe I", team1:"FRA", team2:"SEN", venue:"MetLife Stadium · New York", score1:2, score2:1 },
  { id:50, kickoff:"2026-06-16T22:00:00+02:00", stage:"Groupes", group:"Groupe I", team1:"IRQ", team2:"NOR", venue:"MetLife Stadium · New York", score1:1, score2:1 },
  { id:5,  kickoff:"2026-06-22T19:00:00+02:00", stage:"Groupes", group:"Groupe A", team1:"BRA", team2:"RSA", venue:"SoFi Stadium · Los Angeles", score1:3, score2:0 },
  // — live right now (kickoff passed @ 20:30, no score yet) —
  { id:51, kickoff:"2026-06-22T20:30:00+02:00", stage:"Groupes", group:"Groupe C", team1:"ESP", team2:"GER", venue:"Estadio Azteca · Mexico", score1:null, score2:null },
  // — open for pronos (future) —
  { id:52, kickoff:"2026-06-22T22:00:00+02:00", stage:"Groupes", group:"Groupe I", team1:"FRA", team2:"IRQ", venue:"Lincoln Financial · Philadelphie", score1:null, score2:null },
  { id:53, kickoff:"2026-06-23T19:00:00+02:00", stage:"Groupes", group:"Groupe D", team1:"ENG", team2:"NED", venue:"AT&T Stadium · Dallas", score1:null, score2:null },
  { id:54, kickoff:"2026-06-23T21:00:00+02:00", stage:"Groupes", group:"Groupe E", team1:"POR", team2:"MAR", venue:"Hard Rock Stadium · Miami", score1:null, score2:null },
  { id:55, kickoff:"2026-06-26T19:00:00+02:00", stage:"Groupes", group:"Groupe I", team1:"NOR", team2:"FRA", venue:"Gillette Stadium · Boston", score1:null, score2:null },
  // — knockout placeholders (teams TBD) —
  { id:73, kickoff:"2026-06-29T21:00:00+02:00", stage:"16es", group:"16es de finale", team1:null, team2:null, venue:"À déterminer", score1:null, score2:null },
  { id:74, kickoff:"2026-06-30T21:00:00+02:00", stage:"16es", group:"16es de finale", team1:null, team2:null, venue:"À déterminer", score1:null, score2:null },
  { id:91, kickoff:"2026-07-04T21:00:00+02:00", stage:"Quarts", group:"Quarts de finale", team1:null, team2:null, venue:"À déterminer", score1:null, score2:null },
  { id:101,kickoff:"2026-07-15T21:00:00+02:00", stage:"Finale", group:"Finale", team1:null, team2:null, venue:"MetLife Stadium · New York", score1:null, score2:null },
];

const STAGES = ["Tout","Groupes","16es","Quarts","Demi","Finale"];

/* ─── Scoring (mirrors computePredictionScore: exact 3, bon résultat 1, × boost) ── */
function computePoints(pred, m){
  if(m.score1==null || m.score2==null) return null;
  let base = 0;
  if(pred.s1===m.score1 && pred.s2===m.score2) base = 3;
  else if(Math.sign(pred.s1-pred.s2)===Math.sign(m.score1-m.score2)) base = 1;
  return base * (pred.boost||1);
}
function predOutcome(pred, m){ // 'exact' | 'good' | 'miss'
  if(pred.s1===m.score1 && pred.s2===m.score2) return "exact";
  if(Math.sign(pred.s1-pred.s2)===Math.sign(m.score1-m.score2)) return "good";
  return "miss";
}

/* ─── The league & its members ─────────────────────────────── */
const LEAGUE = { id:"demo", code:"CADOR7", name:"Les Cadors du PMU", members:8 };

// Standings (sorted points desc, exacts desc). "Flo" is the current user.
const STANDINGS = [
  { user_id:"u_flo",  pseudo:"Flo la Science", points:31, played:3, exacts:2, me:true,  streak:3 },
  { user_id:"u_max",  pseudo:"Maxou",          points:27, played:3, exacts:1, me:false, streak:1 },
  { user_id:"u_lea",  pseudo:"Léa",            points:24, played:3, exacts:2, me:false, streak:2 },
  { user_id:"u_kar",  pseudo:"Karim DTC",      points:18, played:3, exacts:1, me:false, streak:0 },
  { user_id:"u_sof",  pseudo:"Sofiane",        points:14, played:3, exacts:0, me:false, streak:1 },
  { user_id:"u_nad",  pseudo:"Nadia 🔥",       points:11, played:3, exacts:1, me:false, streak:0 },
  { user_id:"u_tom",  pseudo:"Tom Tom",        points:7,  played:3, exacts:0, me:false, streak:0 },
  { user_id:"u_bib",  pseudo:"Bibou",          points:3,  played:2, exacts:0, me:false, streak:0 },
];

/* ─── Per-match friend predictions (revealed after kickoff) ──── */
// keyed by match id → [{user_id,pseudo,s1,s2,boost}]
const FRIEND_PREDS = {
  49: [ // FRA 2-1 SEN
    { user_id:"u_flo", pseudo:"Flo la Science", s1:2, s2:1, boost:2, me:true },
    { user_id:"u_lea", pseudo:"Léa",            s1:2, s2:1, boost:1 },
    { user_id:"u_max", pseudo:"Maxou",          s1:1, s2:0, boost:3 },
    { user_id:"u_nad", pseudo:"Nadia 🔥",       s1:2, s2:0, boost:1 },
    { user_id:"u_kar", pseudo:"Karim DTC",      s1:0, s2:1, boost:5 },
    { user_id:"u_sof", pseudo:"Sofiane",        s1:1, s2:1, boost:1 },
    { user_id:"u_tom", pseudo:"Tom Tom",        s1:3, s2:2, boost:1 },
    { user_id:"u_bib", pseudo:"Bibou",          s1:0, s2:0, boost:1 },
  ],
  5: [ // BRA 3-0 RSA
    { user_id:"u_flo", pseudo:"Flo la Science", s1:3, s2:0, boost:1, me:true },
    { user_id:"u_max", pseudo:"Maxou",          s1:2, s2:0, boost:2 },
    { user_id:"u_lea", pseudo:"Léa",            s1:2, s2:1, boost:1 },
    { user_id:"u_kar", pseudo:"Karim DTC",      s1:3, s2:0, boost:1 },
    { user_id:"u_sof", pseudo:"Sofiane",        s1:1, s2:1, boost:3 },
    { user_id:"u_nad", pseudo:"Nadia 🔥",       s1:4, s2:0, boost:1 },
  ],
  51: [ // ESP-GER live, revealed but no result yet
    { user_id:"u_flo", pseudo:"Flo la Science", s1:1, s2:1, boost:2, me:true },
    { user_id:"u_max", pseudo:"Maxou",          s1:2, s2:1, boost:1 },
    { user_id:"u_lea", pseudo:"Léa",            s1:0, s2:1, boost:1 },
    { user_id:"u_kar", pseudo:"Karim DTC",      s1:1, s2:2, boost:2 },
    { user_id:"u_sof", pseudo:"Sofiane",        s1:2, s2:2, boost:1 },
  ],
};

/* ─── My own pronos (saved locally) — incl. 3 not-yet-published ── */
const MY_PRONOS = {
  49:{ s1:2, s2:1, boost:2 },
  50:{ s1:1, s2:1, boost:1 },
  5 :{ s1:3, s2:0, boost:1 },
  51:{ s1:1, s2:1, boost:2 },
  52:{ s1:2, s2:0, boost:3 },   // dirty
  53:{ s1:1, s2:2, boost:1 },   // dirty
  54:{ s1:2, s2:1, boost:1 },   // dirty
};
const DIRTY = [52, 53, 54]; // not published yet

Object.assign(window, {
  NOW, FLAGS, flag, TEAM_NAMES, teamName, H, MATCHES, STAGES,
  computePoints, predOutcome, LEAGUE, STANDINGS, FRIEND_PREDS, MY_PRONOS, DIRTY,
});
